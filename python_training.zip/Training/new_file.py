import python_loop
print("Name: {}".format(__name__))

print(python_loop.add(7,9))