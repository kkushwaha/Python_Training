def add(x,y):
    """
    This function will going to add two integer
    :param x:
    :param y:
    :return: x+y
    """
    return x+y

