x = 42

def blah():
    print(x)