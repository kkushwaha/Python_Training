def add(x,y):
    print("Adding {} and {}".format(x,y))
    return x+y

if __name__ == "__main__":
    add(5,6)
