from mymodule1 import blah

import sys
print(blah.__module__)
#print(blah.__globals__)
print(sys.path)
print(sys.modules['mymodule1'])