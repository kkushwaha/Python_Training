x=42

def foo():
    print("This is foo... modified again again")
