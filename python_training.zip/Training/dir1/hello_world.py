import os



if __name__ == "__main__":
    fp = open('/home/keshav/Desktop/Training/dir1/b.txt','a')
    fp.write('This is new file called b.txt\n')
    fp.close()


