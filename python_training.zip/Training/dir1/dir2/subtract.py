def substract(x,y):
    return x-y
