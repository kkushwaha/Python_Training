import re
# Mini programming language for searching/matching,validating and substituting text


greeting = "hello world"

print(re.search(r"x",greeting))

print(re.search(r"x","exit"))

#finding aeiou in any word
print(re.search(r'[aeiou]',greeting))

print(re.search(r'[0123456789]','$100'))
print(re.search(r'[0-9]','100'))


m = re.search(r'[a-zA-Z0-9_]',greeting)
print(m)

#Negation use cadet sign ^

n = re.search(r'[^0-9]','$100')
print(n)


m = re.search(r'[a-zA-Z0-9_]',greeting)

### Start at the begining called anchor Cadet at the begining of square bracket means negation

p = re.search(r'^a','radical') # matches word only if the string start with a
print(p)

print(re.search(r'^a$','aa'))



print(re.search(r'\[hello\]','[hello]'))

print(re.search(r'a.$','a '))

print(re.search(r'^a.*a$','adfdfdfa'))

print(re.search(r'^[0-9]*$',greeting))

print(re.search(r'[akm$]','pno$'))
print(re.search(r'ca*t','ct'))
print(re.search(r'home-?brew','home-brew'))



