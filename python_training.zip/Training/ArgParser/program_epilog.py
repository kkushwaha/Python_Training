######################################################################
##  ADDING PROGRAM EPILOG
#####################################################################
#python program_epilog.py --help
#usage: myprogram [options]
#
#This is my description added!!!
#
#optional arguments:
#  -h, --help  show this help message and exit
#
#This message comes at the end

import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog='myprogram',
                                     usage='%(prog)s [options]',
                                     description='This is my description added!!!',
                                     epilog='This message comes at the end')
    args = parser.parse_args()