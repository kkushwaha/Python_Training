#ArgumentParser.add_argument(name or flags...[, action][, nargs][, const][, default][, type][, choices][, required][, help][, metavar][, dest])
# THIS PROGRAM DEMONSTRATE the required flag

import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog='myprogram',
                                     usage='%(prog)s [options]',
                                     description='This is my description added!!!',
                                     epilog='This message comes at the end')

    parser.add_argument('--filename',
                        help='Please specify the filename to parse',
                        metavar='yyyyy')
    args = parser.parse_args()

    print("Filename provided by user: {}".format(args.filename))