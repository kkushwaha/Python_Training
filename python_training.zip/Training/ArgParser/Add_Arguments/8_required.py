#ArgumentParser.add_argument(name or flags...[, action][, nargs][, const][, default][, type][, choices][, required][, help][, metavar][, dest])
# THIS PROGRAM DEMONSTRATE the required flag

import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog='myprogram',
                                     usage='%(prog)s [options]',
                                     description='This program will count occurence of characters'
                                                 'in string'
                                                 'Example:'
                                                 '      input: aaaaabzzpppp'
                                                 '       output: a5b1z2p4'
                                     )

    parser.add_argument('--string',
                        help='Please provide string having repeated characters',
                        type=str,
                        required=True)
    args = parser.parse_args()

