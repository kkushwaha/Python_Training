# You need to import argparse module to parse command line argument
# OUTPUT:
# python argument_parsing_1.py --help
#usage: argument_parsing_1.py [-h]
#
#optional arguments:
#  -h, --help  show this help message and exit
#
#

import argparse


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    args = parser.parse_args()

