def add(x,y):
    return x+y


if __name__ == "__main__":
    print("This is main function")
    print("This is python file")