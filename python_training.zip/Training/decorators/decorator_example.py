#Decorator : Decorator is a function that
# takes another
# function as an argument
#            Add some kind of functionality and
# then return another function
#            without altering the function

####outer_function
def decorator_function(original_function):
    def wrapper_function():
        print("Calling Function {}".format(original_function.__name__))
        original_function()
    return wrapper_function

@decorator_function ### This is DECORATOR
def display():
    print("display function ran!!")


#display = decorator_function(display) #@decorator_function
############ Using Decorator
display()

