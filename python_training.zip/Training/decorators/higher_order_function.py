#Higher order function : If function accepts function
# as argument OR return function
# my_map -> is higher order function
# since it accept function as argument
# logger -> logger function is higher
# order function since it return function

def square(x):
    return x*x

def mySquare():
    return square

def my_map(func, arg_list):
    result = []
    for i in arg_list:
        result.append(func(i))
    return result

def cube(x):
    return x*x*x

squares = my_map(square,[1,2,3,4,5])

print(squares)

def logger(message):
    def log_message():
        print("Log: {}".format(message))
    return log_message

def html_tag(tag):
    def wrap_text(msg):
        print("<{0}>{1}</{0}>".format(tag,msg))
    return wrap_text

log_hi = logger("hi")
log_hi()

print_h1 = html_tag("h1")
print_h1('Test Headline')
print_h1('Another Headline!')

print_p = html_tag('p')
print_p("First Paragraph")

