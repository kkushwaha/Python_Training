import logging

logging.basicConfig(filename="log_file.txt",level=logging.INFO)

def logger(func):
    def log_func(*args):
        logging.info('Running "{}" with arguments {}' \
                     .format(func.__name__,args))
        print(func(*args))
    return log_func

@logger
def add(x,y):
    return x+y

@logger
def sub(x,y):
    return x-y

#add = logger(add)
#sub = logger(sub)
print(add)
print(sub)
add(5,7)
sub(18,4)