import threading
import time

sem = threading.Semaphore()

def thrFunc(sleepTime=10):
    threadName = threading.current_thread().getName()
    print("{} Thread running".format(threadName))
    if threading.current_thread().getName() == 'Thread-2':
        print("{} releasing semaphore".format(threadName))
        sem.release()
    sem.acquire()
    print("{} Thread acquired semaphore".format(threadName))
    print("{} sleeping for {} seconds".format(threadName,sleepTime))
    time.sleep(sleepTime)
    print("{} releasing semaphore".format(threadName))
    sem.release()

def main():
    t1 = threading.Thread(target=thrFunc,kwargs={'sleepTime':20})
    t2 = threading.Thread(target=thrFunc, kwargs={'sleepTime': 10})
    t1.start()
    t2.start()
    t1.join()
    t2.join()

if __name__ == "__main__":
    main()
