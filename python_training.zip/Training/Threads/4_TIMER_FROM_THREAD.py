import threading


def hello_world():
    print("Hello World")

t = threading.Timer(10,hello_world)
t.start()

