import threading
import time

tEvent = threading.Event()
tEvent.clear()
def printMessage():
    print("Running Thread {}".format(threading.current_thread().getName()))
    time.sleep(10)
    print("Sleep is Over")
    tEvent.set()

def main():
    t1 = threading.Thread(target=printMessage)
    t1.start()
    print("Waiting for Event to set")
    if not tEvent.wait(20):
        print("Timer Expired!!")
    else:
        print("Event is SET. Now Exiting!!")

if __name__ == "__main__":
    main()