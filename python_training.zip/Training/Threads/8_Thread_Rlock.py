import threading
import random
import time

rLock = threading.RLock()  #### Renenterent Lock
nLock = threading.Lock()  #### Normal Lock

def thrFunc():
    threadName = threading.current_thread().getName()
    print("Thread {} running 1st Time".format(threadName))
    #nLock.acquire()
    rLock.acquire()
    print("Thread {} acquired the lock".format(threadName))
    #nLock.acquire()             ### Acquired the lock second time. PROBLEM can be resolved using Rlock
    rLock.acquire()
    sleepTime = random.randint(10,20)
    print("Thread {} sleeping for {} seconds".format(threadName,sleepTime))
    time.sleep(sleepTime)
    #nLock.release()
    rLock.release()
    print("Thread {} released the lock after {} seconds".format(threadName,sleepTime))

def main():
    t1 = threading.Thread(target=thrFunc)
    t1.start()

if __name__ == "__main__":
    main()

