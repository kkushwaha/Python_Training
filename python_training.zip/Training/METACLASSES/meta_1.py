# To understand metaclasses, first we should make some things clear about classes.
# In Python, everything is an object. And that includes classes.
# In fact, classes in Python are first-class objects
# they can be created at runtime, passed as parameters and returned from functions
# type(name, bases, dict)

#A metaclass is defined as "the class of a class".
# Any class whose instances are themselves classes, is a metaclass.
# type is the most commonly used metaclass in Python, since it's the default metaclass of all classes.





#A class is an object, and just like any other object,
# it's an instance of something: a metaclass. The default metaclass is type
class A:
    pass

print(isinstance(A,type))



# Creating Class at runtime
MyClass = type('MyClass', (), {})

print(MyClass)


# Simple metaclass creation
class Meta(type):
    pass

class B(metaclass=Meta):
    #__metaclass__ = Meta   -> Python 2.x
    pass

print(type(B))