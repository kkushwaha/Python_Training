#To control the creation and initialization of the class in the metaclass,
# you can implement the metaclass's __new__ method and/or __init__
# Most real-life metaclasses will probably override just one of them.
#  __new__ should be implemented when you want to control the creation of a new object (class in our case),
# __init__ should be implemented when you want to control the initialization of the new object after it has been created.

class MyMeta(type):
    def __new__(meta, name, bases, dct):
        print('-----------------------------------')
        print( "Allocating memory for class", name)
        print(meta)
        print(bases)
        print(dct)
        return super(MyMeta, meta).__new__(meta, name, bases, dct)
    def __init__(cls, name, bases, dct):
        print('-----------------------------------')
        print("Initializing class", name)
        print(cls)
        print(bases)
        print(dct)
        super(MyMeta, cls).__init__(name, bases, dct)

class MyKlass(object,metaclass=MyMeta):
    def foo(self, param):
        pass

    barattr = 2

obj1 = MyKlass()