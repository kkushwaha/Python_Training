from openpyxl import Workbook
#You need to install openpyxl python module
#sudo pip install openpyxl


wb = Workbook()
ws = wb.create_sheet("Mysheet",0)

headers = ['name','age','sex','designation','salary']
values = ['Prakash',10,'male','software engineer','340000']
values1 = ['Mohit',40,'male','HR','35000']
ws.append(headers)
ws.append(values)
ws.append(values1)
#ws['A1'] = "NAE"

# Save the file
wb.save("sample.xlsx")
print(wb.sheetnames)
