from tkinter import Tk
from tkinter import filedialog

"""
The tkinter has the following file dialogs:

1) 'askdirectory', 
2) 'askopenfile', 
3) 'askopenfilename', 
4) 'askopenfilenames', 
5) 'askopenfiles', 
6) 'asksaveasfile', 
7) 'asksaveasfilename'
"""

"""
result=filedialog.askopenfilename()
print("Result: {}".format(result))

result=filedialog.askopenfilenames()
print("Result: {}".format(result))

result=filedialog.askopenfile()
print("Result: {}".format(result))


result=filedialog.asksaveasfile()
"""
root = Tk()
root.filename = filedialog.askopenfilename(initialdir="/home/keshav", title="Select file",
                                           filetypes=(("jpeg files", "*.jpg"), ("all files", "*.*")))
print(root.filename)


