from tkinter import *
from tkinter import messagebox

"""
Following Dialog Boxes are Available in Tkinter:
All messagebox has the following format
(Title,Message)
1) 'askokcancel'
2) 'askquestion'
3) 'askretrycancel'
4) 'askyesno'
5) 'askyesnocancel'
6) 'showerror'
7) 'showinfo' 
8) 'showwarning'
"""



def answer():
    messagebox.showerror("Answer", "Sorry, no answer available")

def callback():
    if messagebox.askyesno('Verify', 'Really quit?'):
        messagebox.showwarning('Yes', 'Not yet implemented')
    else:
        messagebox.showinfo('No', 'Quit has been cancelled')

Button(text='Quit', command=callback).pack()
Button(text='Answer', command=answer).pack()
mainloop()