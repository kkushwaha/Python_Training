from tkinter import *

class App:
    def __init__(self,master):
        master.minsize(width=600, height=800)
        master.maxsize(width=800, height=1000)
        master.title("LABEL EXAMPLE")

    def createLabel(self,master):
        Label(master,text="Red Text in Times Font",fg = "red",font = "Times").pack()
        Label(master,text="Green Text in Helvetica Font",fg = "light green",bg = "dark green",font = "Helvetica 16 bold italic").pack()
        Label(master,text="Blue Text in Verdana bold",fg = "blue",bg = "yellow",font = "Verdana 10 bold").pack()

top = Tk()
app = App(top)
app.createLabel(top)
top.mainloop()