import json

if __name__ == "__main__":
    myEmpDict = {
	"First_Name": "Prakash",
	"Last_NAme": "Mehta",
	"Age": 26,
	"Sex": "Male",
	"Income": 20000
    }

    json_string = json.dumps(myEmpDict)
    print(json_string)
    print(type(json_string))
