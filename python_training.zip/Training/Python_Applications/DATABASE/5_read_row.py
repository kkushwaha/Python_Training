# Read operation on database means fetch some useful information from the database
# Below are the three operation that you can perform on database for read.
# fetchone() − It fetches the next row of a query result set. A result set is an object that is returned when a cursor object is used to query a table.
#fetchall() − It fetches all the rows in a result set. If some rows have already been extracted from the result set, then it retrieves the remaining rows from the result set.
#rowcount − This is a read-only attribute and returns the number of rows that were affected by an execute() method.

import pymysql
from collections import namedtuple


if __name__ == "__main__":
    emp = namedtuple('employee', 'first_name' 'last_name' 'age' 'sex' 'income')
    # Open database connection
    db = pymysql.connect(host="localhost", user="root", password="keshav", database="Tutorials")

    # prepare a cursor object using cursor() method
    cursor = db.cursor()

    # Prepare SQL query to INSERT a record into the database.
    sql = "SELECT * FROM EMPLOYEE \
           WHERE INCOME > '%d'" % (1000)

    ################### FETCHING ONE ROW AT A TIME
    # Execute the SQL command
    try:
        print("{0} FETCH ONE ROW {0}".format("=" * 40))
        cursor.execute(sql)
        # Get Row Count
        rowCount = cursor.rowcount
        while rowCount > 0:
            # Fetch one row at a time
            row = cursor.fetchone()
            emp.first_name, emp.last_name, emp.age, emp.sex, emp.income = row
            print(emp.first_name, emp.last_name, emp.age, emp.sex, emp.income)
            rowCount=rowCount-1
    except:
        print("Error UNABLE to fetch SINGLE ROW")


    ####################  FETCHING ALL ROW AT A TIME
    try:
       print("{0} FETCH ALL ROW {0}".format("=" * 40))
       # Execute the SQL command
       cursor.execute(sql)
       # Fetch all the rows in a list of lists.
       results = cursor.fetchall()
       rowCount = cursor.rowcount
       print("Total Count: {}".format(rowCount))
       for row in results:
           emp.first_name, emp.last_name, emp.age, emp.sex, emp.income = row
           print(emp.first_name,emp.last_name,emp.age,emp.sex,emp.income)
    except:
       print ("Error: unable to fetch data")

    # disconnect from server
    db.close()