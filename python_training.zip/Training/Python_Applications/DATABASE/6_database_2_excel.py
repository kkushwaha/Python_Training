from openpyxl import Workbook
import pymysql
from collections import namedtuple
from openpyxl.chart import BarChart,BarChart3D, Reference, Series

if __name__ == "__main__":
    wb = Workbook()
    ws = wb.active
    emp = namedtuple('employee', 'first_name' 'last_name' 'age' 'sex' 'income')
    # Open database connection
    db = pymysql.connect(host="localhost", user="root", password="keshav", database="Tutorials")

    # prepare a cursor object using cursor() method
    cursor = db.cursor()

    # Prepare SQL query to INSERT a record into the database.
    sql = "SELECT * FROM EMPLOYEE \
           WHERE INCOME > '%d'" % (1000)

    ####################  FETCHING ALL ROW AT A TIME
    try:
       print("{0} FETCH ALL ROW {0}".format("=" * 40))
       # Execute the SQL command
       cursor.execute(sql)
       # Fetch all the rows in a list of lists.
       results = cursor.fetchall()
       rowCount = cursor.rowcount
       print("Total Count: {}".format(rowCount))
       ws.append(['FIRST_NAME','LAST_NAME','AGE','SEX','INCOME'])
       for row in results:
           emp.first_name, emp.last_name, emp.age, emp.sex, emp.income = row
           print(emp.first_name,emp.last_name,emp.age,emp.sex,emp.income)
           ws.append(row)
       data = Reference(ws,min_col=5,min_row=2,max_row=rowCount+2)
       titles = Reference(ws,min_col=1,min_row=2,max_row=rowCount+2)
       chart = BarChart3D()
       chart.title = "EMPLOYEE SALARY DETAIL"
       chart.height = 12
       chart.width = 25
       chart.set_categories(titles)
       chart.add_data(data=data,titles_from_data=True)
       ws.add_chart(chart, "H16")
    except:
       print ("Error: unable to fetch data")

    # disconnect from server
    wb.save("db2excel.xls")
    db.close()