import pymysql
'''
mysql> use Tutorials;
Reading table information for completion of table and column names
You can turn off this feature to get a quicker startup with -A

Database changed
mysql> select * from EMPLOYEE;
Empty set (0.00 sec)

mysql> select * from EMPLOYEE;
+------------+-----------+------+------+--------+
| FIRST_NAME | LAST_NAME | AGE  | SEX  | INCOME |
+------------+-----------+------+------+--------+
| Prakesh    | Mehta     |   20 | M    |   2000 |
+------------+-----------+------+------+--------+
1 row in set (0.00 sec)

mysql> 
'''

if __name__ == "__main__":
    # Open database connection
    db = pymysql.connect(host="localhost",user="root",password="keshav",database="Tutorials" )

    # prepare a cursor object using cursor() method
    cursor = db.cursor()

    # Prepare SQL query to INSERT a record into the database.
    sql = "INSERT INTO EMPLOYEE" \
          "(FIRST_NAME,LAST_NAME,AGE,SEX,INCOME)" \
          " VALUES('{}','{}','{}','{}','{}')".format('Prakesh', 'Mehta', 20, 'M', 2000)

    print("Mysql Query: {}".format(sql))
    try:
       print("Committing Transaction")
       # Execute the SQL command
       cursor.execute(sql)
       # Commit your changes in the database
       db.commit()
    except Exception as e:
       # Rollback in case there is any error
       print("Exception {} occurred".format(e.args))
       db.rollback()

# disconnect from server
db.close()
