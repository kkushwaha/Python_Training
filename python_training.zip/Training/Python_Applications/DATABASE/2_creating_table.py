import pymysql

'''
mysql> use Tutorials;
Reading table information for completion of table and column names
You can turn off this feature to get a quicker startup with -A

Database changed
mysql> show tables;
+---------------------+
| Tables_in_Tutorials |
+---------------------+
| EMPLOYEE            |
+---------------------+
1 row in set (0.00 sec)

mysql> show columns from EMPLOYEE;
+------------+----------+------+-----+---------+-------+
| Field      | Type     | Null | Key | Default | Extra |
+------------+----------+------+-----+---------+-------+
| FIRST_NAME | char(20) | NO   |     | NULL    |       |
| LAST_NAME  | char(20) | YES  |     | NULL    |       |
| AGE        | int(11)  | YES  |     | NULL    |       |
| SEX        | char(1)  | YES  |     | NULL    |       |
| INCOME     | float    | YES  |     | NULL    |       |
+------------+----------+------+-----+---------+-------+
5 rows in set (0.01 sec)

mysql> 
'''

if __name__ == "__main__":
    # Open database connection
    db = pymysql.connect(host="localhost",user="root",password="keshav",database="Tutorials" )

    # prepare a cursor object using cursor() method
    cursor = db.cursor()

    # Drop table if it already exist using execute() method.
    cursor.execute("DROP TABLE IF EXISTS EMPLOYEE")

    # Create table as per requirement
    sql = "CREATE TABLE EMPLOYEE ( \
       FIRST_NAME  CHAR(20) NOT NULL, \
       LAST_NAME  CHAR(20), \
       AGE INT,   \
       SEX CHAR(1), \
       INCOME FLOAT )"

    cursor.execute(sql)

    # disconnect from server
    db.close()
