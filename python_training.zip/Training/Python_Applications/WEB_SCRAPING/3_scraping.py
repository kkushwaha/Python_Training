"""
NavigableString
A string corresponds to a bit of text within a tag.
Beautiful Soup uses the NavigableString class to contain
these bits of text:

tag.string
# u'Extremely bold'
type(tag.string)
# <class 'bs4.element.NavigableString'>
A NavigableString is just like a Python Unicode string, except that it also supports some of the features described in Navigating t
he tree and Searching the tree. You can convert a NavigableString to a Unicode string with unicode():

unicode_string = unicode(tag.string)
unicode_string
# u'Extremely bold'
type(unicode_string)
# <type 'unicode'>
You can’t edit a string in place, but you can replace one string with another, using replace_with():

tag.string.replace_with("No longer bold")
tag
# <blockquote>No longer bold</blockquote>
NavigableString supports most of the features described in Navigating the tree and Searching the tree, but not all of them. I
"""