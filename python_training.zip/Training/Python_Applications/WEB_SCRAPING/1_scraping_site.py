import requests
from bs4 import BeautifulSoup
"""
Beautiful soup Document:
https://www.crummy.com/software/BeautifulSoup/bs4/doc/
"""

page = requests.get('https://en.wikipedia.org/wiki/States_and_union_territories_of_India')

soup = BeautifulSoup(page.text, 'html.parser')

print(soup.prettify())


