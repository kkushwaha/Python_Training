#Method	Description
#s.connect()	This method actively initiates TCP server connection.
#
#
#
#Method	Description
#s.recv()	    This method receives TCP message
#s.send()	    This method transmits TCP message
#s.recvfrom()	This method receives UDP message
#s.sendto()	    This method transmits UDP message
#s.close()	    This method closes socket
import socket               # Import socket module

s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name
port = 2345                # Reserve a port for your service.

s.connect((host, port))
print("Received from Server: {}".format(s.recv(1024)))
s.close