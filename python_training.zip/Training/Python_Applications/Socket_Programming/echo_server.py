import socket               # Import socket module

s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name
port = 1345                # Reserve a port for your service.
s.bind((host, port))        # Bind to the port

s.listen()                 # Now wait for client connection.
while True:
   c, addr = s.accept()     # Establish connection with client.
   print('Got connection from: {}'.format(addr))
   recv_message = c.recv(1024)
   print("Received Message: {}".format(recv_message))
   c.close()                # Close the connection