#Sockets are the endpoints of a bidirectional communications channel.

#Sockets may be implemented over a number of different channel types:
#Unix domain sockets, TCP, UDP, and so on.
#The socket library provides specific classes for handling
#the common transports as well as a generic interface for handling the rest.

#SOCKET TERMINOLOGY:
#domain	    The family of protocols that is used as the transport mechanism. These values are constants such as AF_INET, PF_INET, PF_UNIX, PF_X25, and so on.
#type	    The type of communications between the two endpoints, typically SOCK_STREAM for connection-oriented protocols and SOCK_DGRAM for connectionless protocols.
#protocol	Typically zero, this may be used to identify a variant of a protocol within a domain and type.
#hostname	The identifier of a network interface:
#           A string, which can be a host name, a dotted-quad address, or an IPV6 address in colon (and possibly dot) notation
#           A string "<broadcast>", which specifies an INADDR_BROADCAST address.
#           A zero-length string, which specifies INADDR_ANY, or
#           An Integer, interpreted as a binary address in host byte order.
#port	    Each server listens for clients calling on one or more ports. A port may be a Fixnum port number, a string containing a port number, or the name of a service.

################# SERVER METHODS #############################
#Server Socket Methods
#Method	Description
#s.bind()	This method binds address (hostname, port number pair) to socket.
#s.listen()	This method sets up and start TCP listener.
#s.accept()	This passively accept TCP client connection, waiting until connection arrives (blocking).

import socket               # Import socket module

s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name
port = 2345                # Reserve a port for your service.
s.bind((host, port))        # Bind to the port

s.listen()                 # Now wait for client connection.
while True:
   c, addr = s.accept()     # Establish connection with client.
   print('Got connection from: {}'.format(addr))
   c.send('Thank you for connecting'.encode())
   c.close()                # Close the connection
