


if __name__ == "__main__":
    f=lambda x,y:x+y
    print(f(8,10))