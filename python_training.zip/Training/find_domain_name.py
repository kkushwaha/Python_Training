import argparse
import re

if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument('--filename',
                        type=open,
                        help='Please specify the string to compress.'
                        )


    args = parser.parse_args()
    print("Filename : {}".format(args.filename))
