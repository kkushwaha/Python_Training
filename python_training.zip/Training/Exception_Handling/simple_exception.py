"""
User can handle the exception using try: except:

Inside Try: block user need to provide the expression which he is suspecting in
result exception. If there is NO exception the try: block statements will get executed.
In case exception occur while executing Try block statement the statements in except
block will get executed.

Below in an example of try: except: the user can have any number of except blocks to handle different
kind of exceptions. Like IndexError,ValueError etc.

In case user is NOT sure what exeception can be raised or user want to just handle an exception
he can use the statement like except Exception as e in this case the execption detail is get stored in variable e

User can prinit the e.args OR e.message detail which is having some information about the exception.
"""

import traceback

def fetcher(obj,index):
    try:
        return obj[index]
    except IndexError:
        print("IndexError Occurred.{}".format(traceback.format_exc()))
    except ValueError:
        print("ValueError Occurred")
    except Exception as e:
        print("Exception {} occurred".format(e))
    finally:
        print("function is returning")


def main():
    x='spam'
    fetcher(x,3)

if __name__ == "__main__":
    main()
    print("Exiting Main")