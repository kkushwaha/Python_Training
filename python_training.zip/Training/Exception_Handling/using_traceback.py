""""
Traceback is the python module which can be used to print the backtrace when exception occur in your script.
In will be having detail of the line number and functions which get called while exception occurred.

this will help programmer to identify the point of failure/exception.

Below is the example explaining how to print the backtrack whenever exception is raised.
"""



import traceback

def getIndex(mylist,index):
    try:
        return mylist[index]
    except:
        print("Below is the exception:")
        print(traceback.format_exc())

def myprogram():
    list1 = [1, 2, 3, 5]
    returnValue = getIndex(list1, 21)
    print(returnValue)

if __name__ == "__main__":
    myprogram()
    print("Exiting the program")