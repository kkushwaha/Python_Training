def function_example(*args,**kwargs):
    print("Arugment: \
    and args={} and kwargs={}".format(args,kwargs))


function_example(6,10,40,50,a=70,b=500,z=300)