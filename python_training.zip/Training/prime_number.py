def isPrime(number):
    """
    :param number: The number which need to be check for prime/non-prime
    :return: Return True if number is prime else return False
    """
    for integer in range(2,int(number/2)+2):
        if number % integer == 0:
            return False
    else:
        return True



if __name__ == "__main__":
    print(list(filter(isPrime,range(2,100))))
