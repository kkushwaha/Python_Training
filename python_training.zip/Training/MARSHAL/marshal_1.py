import marshal

list1 = [ x for x in range(100) if x%2 == 0 ]
print(list1)

with open('list1.marshal','wb') as fp:
    marshal.dump(list1,fp)

list1Str = marshal.dumps(list1)
print(type(list1Str))

list2 = marshal.loads(list1Str)
print("List2 : {}".format(list2))
list2.append(9999)
print("List1 : {}".format(list2))
print("List2 : {}".format(list2))

dict1 = {
          'name': "Prakash",
          'age': 34,
           "sex": "male",
           "address" : "Pune",
           "profession": "software engineer"
         }
print(dict1)

with open('dict1.marshal','wb') as fp:
    marshal.dump(dict1,fp)

