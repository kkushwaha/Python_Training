import marshal


with open('list1.marshal','rb') as fp:
    mylist = marshal.load(fp)

print("My List: {}".format(mylist))

with open('dict1.marshal','rb') as fp:
    myDict = marshal.load(fp)


print("My Dict : {} ".format(myDict))