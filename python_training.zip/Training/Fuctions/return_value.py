def display():
    return "hello"

print(display())