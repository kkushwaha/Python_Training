from dummy_module import x
#x=100

def myfunc():
    #x=400
    def innerFunc():
        #x=900
        print("X is : {}".format(x))
    innerFunc()

myfunc()