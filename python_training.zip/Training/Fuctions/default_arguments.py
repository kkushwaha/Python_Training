def myfunc(x,data=[]):
    data.append(60)
    print("First Arg: {} and Default:{}".format(x,data))


if __name__ == "__main__":
    myfunc(x=10)
    myfunc(x=10)
    myfunc(x=10,data=[600])
    myfunc(x=10)
    myfunc(x=10, data=[6,10,100])
