import re

def grep(pattern,filename):
    for line in open(filename):
        if re.search(pattern,line):
            yield line


if __name__ == "__main__":
    for result in grep(pattern='int',filename='/home/keshav/add.c'):
        print(result)
