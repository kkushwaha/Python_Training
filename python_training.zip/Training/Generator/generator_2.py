import memory_profiler as mem_profile
import random
import time

names = ['Prakash','Rohit','Mohan','Uday']
majors = ['Math','Comps','Science']

def getMemUsage(func):
    def wrapper(*args):
        print('Memory (Before[{}]): {}Mb' \
              .format(func.__name__,mem_profile.memory_usage()))
        t1 = time.clock()
        result = func(*args)
        t2 = time.clock()
        print('Memory (After[{}]): {}Mb' \
              .format(func.__name__,mem_profile.memory_usage()))
        print('Took {} Seconds'.format(t2 - t1))
        return result
    return wrapper

@getMemUsage
def people_list(num_people):
    results = []
    for i in range(num_people):
        person = {
                    'id':i,
                    'name': random.choice(names),
                    'major':random.choice(majors)
                  }
        results.append(person)
    return results

@getMemUsage
def people_generator(num_people):
    for i in range(num_people):
        person = {
                    'id':i,
                    'name': random.choice(names),
                    'major':random.choice(majors)
                  }
        yield person


people = people_list(1000000)
#gen_people = people_generator(1000000)


