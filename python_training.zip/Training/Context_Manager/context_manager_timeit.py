import time
class timeIt(object):
    def __init__(self):
        self.startTime = time.time()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.totalTime = time.time() - self.startTime


with timeIt() as getTime:  ### getTime=timeIt()
    print("Sleeping for 20 seconds...")
    time.sleep(20)

print("Total Time: {}".format(getTime.totalTime))