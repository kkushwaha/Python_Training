def isPerfect(number):
    """
    :param number: The number to be check for perfect/non perfect
    :return: True if number is perfect else False
    """
    factors = 0
    for integer in range(1,int(number/2)+2):
        if number % integer == 0:
            factors+=integer
    if factors == number:
        return True
    else:
        return False

if __name__ == "__main__":
    print(list(filter(isPerfect,range(2,10000))))