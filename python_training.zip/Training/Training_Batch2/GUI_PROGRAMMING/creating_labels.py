from tkinter import *

window = Tk()

Label(window,
		 text="Red Text in Times Font",
		 fg = "red",
		 font = "Times").pack()
Label(window,
		 text="Green Text in Helvetica Font",
		 fg = "light green",
		 bg = "dark green",
		 font = "Helvetica 16 bold italic").pack()
Label(window,
		 text="Blue Text in Verdana bold",
		 fg = "blue",
		 bg = "yellow",
		 font = "Verdana 10 bold").pack()

window.title("LABEL EXAMPLE")

window.mainloop()