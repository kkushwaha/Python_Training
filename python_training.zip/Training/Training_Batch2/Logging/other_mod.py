import logging


# ----------------------------------------------------------------------
def add(x, y):
    """"""
    #logger = logging.getLogger("other_mod")
    #logger.info("added %s and %s to get %s" % (x, y, x + y))
    logging.info("added %s and %s to get %s" % (x, y, x + y))
    return x + y