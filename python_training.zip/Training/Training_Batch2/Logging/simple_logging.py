import logging

FORMAT = '%(asctime)s %(name)s %(levelname)s %(message)s'
logging.basicConfig(level=logging.INFO,format=FORMAT)
fh=logging.FileHandler('new_logs.txt')
fh.setFormatter(logging.Formatter(FORMAT))
logging.getLogger('').addHandler(fh)
logging.debug("This is a debug message")
logging.info("Informational message")
logging.error("An error has happened!")

