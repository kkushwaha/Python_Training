class Vehical(object):
    classVariable = 0
    def __init__(self):
        print("INIT gets Called")
        Vehical.classVariable += 1
        self.vehicalType = "Fourwheeler"
        self.price = 10000

    def __new__(cls,*args,**kwargs):
        print("New Gets Called")
        return super().__new__(cls,*args,**kwargs)
        # super(classname,object).
    def foo(self,*args):
        print("this is foo: {}".format(args))

    def __call__(cls, *args, **kwargs):
        print("Calling call method")
        #return super().__call__(cls,*args,**kwargs)

    def __str__(self):
        return "Class Vehical to store vehical information"

    def __repr__(self):
        return "Vehical(vehicalType={})".format(self.vehicalType)

    def __add__(self, other):
        return self.price + other.price

    def __len__(self):
        return len(self.vehicalType)

def hello():
    print("Hello Hello")

print("Class Variable: {}".format(Vehical.classVariable))
object1 = Vehical()
object2 = Vehical()
object1.price=50000
object2.price=20000
print(repr(object1))
print("Class Varaible using object: {}".format(object1.classVariable))
object1.foo(1,2,3,4)
print("Number of Object Created: {}".format(Vehical.classVariable))
print("sum : {}".format(object1+object2))
print("length : {}".format(len(object1)))
object1()