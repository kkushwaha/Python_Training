'''
1. __str__
2. __repr__

'''
class Employee(object):
    def __init__(self,name,age):
        print('Init method get called')
        self.name = name
        self.age = age

    def __str__(self):
        return 'Employee(name,age)'

    def __repr__(self):
        return 'Employee({},{})' \
            .format(self.name,self.age)


if __name__ == "__main__":
    ob1 = Employee(name="Robin",age="34")
    print(ob1)          #### This will execute __str__
    print(repr(ob1))    #### This will execute __repr__