import os

class changeDir(object):
    def __init__(self, newDir):
        self.saveDir = os.getcwd()
        self.newDir = newDir

    def __enter__(self):
        print("Changing Dir from {0} to {1}".format(os.getcwd(), self.newDir))
        os.chdir(self.newDir)

    def __exit__(self, *args):
        print("Changing Dir from {1} to {0}".format(os.getcwd(),self.saveDir))
        os.chdir(self.saveDir)

if __name__ == "__main__":
    print("Current Directory : {}".format(os.getcwd()))
    with changeDir("/home/keshav"):
        print("Inside context manager: {}".format(os.getcwd()))
    print("Exited from Contetxt Manager")