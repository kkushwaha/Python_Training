def square(x):
    """
    This function will calculate square of x
    :param x:
    :return: x*x
    """
    return x*x

def myFunc():
    """
    This function return function hence called Higher
    order function
    :return:
    """
    return square

if __name__ == "__main__":
    print(myFunc.__doc__)
    print(myFunc.__name__)
    newSquare = myFunc()
    result = newSquare(8)
    print("Result : {}".format(result))