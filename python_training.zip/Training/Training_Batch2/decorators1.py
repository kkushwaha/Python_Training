def reverseString(func):
    """
    This is decorator which will take function as arugment
    and modify its behaviour
    :param func:
    :return:
    """
    def inner_function(message):
        return func(message)[::-1]
    return inner_function

@reverseString
def printMsg(message):
    return message

if __name__ == "__main__":
    #myfunc = printHello(printHi)
    #myfunc()
    #printMsg = reverseString(printMsg) is equivalent to @printHello
    print(printMsg("simple string"))
    msg = "hi"
