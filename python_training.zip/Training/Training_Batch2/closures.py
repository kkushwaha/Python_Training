def outer_function():
    """
    This is outer function which is having closure
    :return:
    """
    x=500
    print("This is outer function")
    def inner2():
        x=900
        print("this is second inner function")

    def inner_function():
        """
        This is closure function defined inside another function
        :return:
        """
        print("This is inner function")
        print("Value from outer function: {}".format(x))
    inner_function()
    inner2()

if __name__ == "__main__":
    outer_function()


