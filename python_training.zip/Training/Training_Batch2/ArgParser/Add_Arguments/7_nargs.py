#ArgumentParser.add_argument(name or flags...[, action][, nargs][, const][, default][, type][, choices][, required][, help][, metavar][, dest])
# THIS PROGRAM DEMONSTRATE nargs value
#

import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog='myprogram',
                                     usage='%(prog)s [options]',
                                     description='This is my description added!!!',
                                     epilog='This message comes at the end')

    parser.add_argument('--expected_string', nargs='?', help='Provide the regex string to search in file',
                        default='\w+\s+')  ##Positional Argument
    parser.add_argument('--filename',nargs=2,help='Provide the filename to parse',default='myfile.txt')  # nargs=2 means it expect two arguments for --filename
    # ? -> 0 or 1
    # + -> 1 or more
    # * -> 0 or more
    # argparse.REMAINDER to get rest of the arguments

    #parser.add_argument('args', nargs=argparse.REMAINDER, help='This will take rest of the remainder arguments')  ##REMAINDER ARGUMENTS

    parser.print_help()
    args = parser.parse_args()
    print("Positional Argument: {}".format(args.expected_string))
    print("Optional Arugment: {}".format(args.filename))
    print('filename type: {}'.format(type(args.filename)))
    #print('remainder args: {}'.format(args.args))