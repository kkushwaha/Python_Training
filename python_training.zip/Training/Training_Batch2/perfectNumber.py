def isPerfect(number):
    sum_of_factors=0
    for factor in range(2,int(number/2)+1):
        if number % factor == 0:
            sum_of_factors = sum_of_factors + factor

    if number == (sum_of_factors+1):
        return True
    else:
        return False

if __name__ == "__main__":
    print(list(filter(isPerfect,range(2,100000))))

###############
pow(2,n-1) * pow(2,n) -1
Where n is prime number

prime number : 2
2*1=2
2*2-1=3
6

3*2=6