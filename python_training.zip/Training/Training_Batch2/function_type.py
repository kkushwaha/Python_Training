def funcWithAnyArgs(*args):
    print("Args: {}".format(args))
    print("Args[0]: {}".format(args[0]))

def funcWithDefaultArgs(name,age=50):
    print("Name: {} and Age: {}".format(name,age))

def funcWithKeyWordArgs(**kwargs):
    print("KeyWords Arguments: {}".format(kwargs))
    for key in kwargs:
        print("Key : {} and Value: {}".format(key,kwargs[key]))

def genericFunc(*args,**kwargs):
    print("Arguments: {}".format(args))
    print("KeyWord Args: {}".format(kwargs))

funcWithAnyArgs(45,89,90,100,890,23,0)
funcWithDefaultArgs('Prakash')
funcWithDefaultArgs(name='Prakash',age=90)
funcWithKeyWordArgs(name='Mohit',age=90,address='Pune')
genericFunc(90,89,67,'Mohit',key1='pawan',key2=99)