import sys
import logging
FORMAT = '%(asctime)s %(name)s %(levelname)s %(message)s'
logging.basicConfig(filename='mylogfile.txt',level=logging.DEBUG,format=FORMAT)
myloger = logging.getLogger("My_LOGS")
ch = logging.StreamHandler(sys.stdout)
myloger.addHandler(ch)

def enter_exit(func):
    def wrapper(n):
        myloger.debug("Entering Function: {}".format(func.__name__))
        func(n)
        myloger.debug("Exiting Function: {}".format(func.__name__))
    return wrapper


@enter_exit  #### square = enter_exit(square)
def square(n):
    myloger.info("Square of number {}: {}".format(n,n*n))


def add(x,y):
    myloger.info("Sum of number {} and {}: {}".format(x,y,x+y))

if __name__ == "__main__":
    square(5)
    add(9,10)