import pickle
from pickle_1 import A  # You need to import class A from other python file

with open('list1.pickle','rb') as fp:
    mylist = pickle.load(fp)

print("My List: {}".format(mylist))

with open('dict1.pickle','rb') as fp:
    myDict = pickle.load(fp)


print("My Dict : {} ".format(myDict))

with open('classA.pickle','rb') as fp:
    myObj = pickle.load(fp)

print("Class Object Name: {} and Age : {}".format(myObj.name,myObj.age))