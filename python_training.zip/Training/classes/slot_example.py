class MyClass(object):
    count = 0
    """
    This is simple class to demonstrate python class type
    """

    def __init__(self):
        self.name = "Rishi"
        self.age = 23
        self.designation = {'abc':10,'xyz':20}


    __slots__ = ("name","age","designation")

if __name__ == "__main__":
    obj1 = MyClass()
    print(obj1.name,obj1.age)
    print(obj1.__sizeof__())
    print()



