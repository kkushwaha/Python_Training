from weather_example import Weather

ob1 = Weat
print(ob1.tempConverter(56))