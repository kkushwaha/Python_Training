def grep(pattern,lines):
    for line in lines:
        if pattern in line:
            yield line


logFile = open('abc.txt')
gen = grep('15-04-2017 17:07:42',logFile)
for value in gen:
    print(value)
