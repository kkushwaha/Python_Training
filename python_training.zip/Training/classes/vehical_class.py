class Vehical(object):
    """
        This is vehical class which will
        going to store the detail of vehical
    """
    objectCount = 0
    def __init__(self,car="Maruti",wCount=4):
        Vehical.objectCount +=1
        print("Initializing class")
        self.car = car
        self.wheel = "axel"
        self.wheelCount = wCount
        assert self.wheelCount <=4,print("Wheel Count is greater than 4")

    def checkVehicalType(self):
        if self.car == "Maruti":
            print("This is Maruti Car")
        else:
            print("Car is : {}".format(self.car))

class FourWheeler(Vehical):
    pass

if __name__ == "__main__":
    obj1 = FourWheeler()
    print(obj1.__dict__)
    if obj1.__class__ == FourWheeler:
        print("This is FourWheeler Class")
    print("Class Name is: {}".format(obj1.__class__))
    print("Total Object Created: {}".format(Vehical.objectCount))
    if hasattr(obj1,"")
