class Reverse(object):
    "Iterator for looping service"

    def __init__(self,data):
        self.data = data
        self.stringLength = len(data)

    def __iter__(self):
        return self

    def __next__(self):
        if self.stringLength == 0:
            raise StopIteration
        else:
            self.stringLength = self.stringLength - 1
            return self.data[self.stringLength]

obj1 = Reverse('abcd')
#print(iter(obj1) is iter(obj1))
for i in obj1:
    print('{}'.format(i),end='')