if __name__ == "__main__":
    print("This won't get printed when imported")