class MyClass(object):
    def __init__(self,first,last,email):  ### constructor or initialize variables
        print("This is constructor")
        self.firstName=first
        self.lastName=last
        self.email=email

    def printDetail(self):
        return ("Values: {},{},{}".format(self.firstName,self.lastName,self.email))


ob1=MyClass("Prakash","Mehra",'pmehra@gmail.com')  #### a=10 or str1 = 'prakash'
ob3=[]
for i in range(1,4):
    first,last,email=input('enter values(first,last,email):').split(',')
    ob3.append(MyClass(first,last,email))
print(ob3)
for i in range(0,3):
    print(ob3[i].printDetail())

