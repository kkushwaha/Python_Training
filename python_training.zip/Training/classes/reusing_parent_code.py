class Shape(object):
    def area(self):
        print("Calculating Area:")

class Square(Shape):
    def __init__(self,side):
        self.side = side

    def area(self):
        super(Square,self).area()   ### Will call parent area method
        print("Square Area: {}".format(self.side**2))

sqaureObject = Square(24)
sqaureObject.area()