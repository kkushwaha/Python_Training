import time
import logging

FORMAT = '%(asctime)s %(levelname)s %(message)s'
logging.basicConfig(filename='function_logs.txt',level=logging.INFO,format=FORMAT,datefmt='%Y-%m-%d %H:%M:%S')

def timeit(original_function):
    def wrapper_function(*args):
        start_time = time.time()
        result = original_function(*args)
        elapsed_time = time.time() - start_time
        print("Time Taken by \"{}\" function : {}".format(original_function.__name__,elapsed_time))
        return result
    return wrapper_function

def logMsg(original_function):
    def wrapper_function(*args):
        logging.info("Executing \"{}\" function".format(original_function.__name__))
        result = original_function(*args)
        return result
    return wrapper_function

@timeit
@logMsg
def add(x,y):
    return x+y

print(add(6,8))
