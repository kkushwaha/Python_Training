def mygenator(n):
    i=0
    while i < n:
        yield i
        i = i+1
#print(type(mygenator))

gen = mygenator(6)
print(gen)
print(gen.__next__())  # 2.7 use next()
print(gen.__next__())
print(gen.__next__())
print(gen.__next__())
print(gen.__next__())
print(gen.__next__())



