import sys

print(sys.argv)
if "--functionName" in sys.argv:
    print("Function Name is passed")