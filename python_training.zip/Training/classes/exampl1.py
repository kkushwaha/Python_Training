print(__name__)

if __name__ == "__main__":
    print("Main get executed")